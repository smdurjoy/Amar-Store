
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Catalogues</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active"><a href="<?php echo e(url('admin/add-edit-banner')); ?>">Add Banner</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(Session::has('successMessage')): ?>
                    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                        <?php echo e(Session::get('successMessage')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <!-- Add banner form -->
                <form method="post" <?php if(empty($banner['id'])): ?> action="<?php echo e(url('admin/add-edit-banner')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-banner/'.$banner['id'])); ?>" <?php endif; ?> id="addbannerForm" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title"> <?php echo e($title); ?> </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="banner_title">Banner Title</label>
                                        <input type="text" class="form-control" placeholder="Enter banner title" name="banner_title" id="bannerTitle" <?php if(!empty($banner['title'])): ?> value="<?php echo e($banner['title']); ?>" <?php else: ?> value="<?php echo e(old('$banner_title')); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <!-- /.col -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputFile">Banner Image</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="bannerImage" name="banner_image">
                                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                            </div>
                                        </div>
                                        <small class="text-muted">Recommended Image Size: 1170 x 480 px</small>
                                    </div>
                                    <div>
                                        <?php if(!empty($banner['image'])): ?>
                                            <img src="<?php echo e(asset('images/bannerImages/'.$banner['image'])); ?>" alt="image!" style="height: 80px; width: 180px; margin-bottom: 10px">&nbsp; 
                                            <a class="confirmDelete" href="javascript:void(0)" record="banner-image" recordId="<?php echo e($banner['id']); ?>">Delete Photo</a>
                                        <?php endif; ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div> 
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->

                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="banner_link">Banner Link</label>
                                        <input type="text" class="form-control" placeholder="Enter banner link" name="banner_link" id="bannerLink" <?php if(!empty($banner['link'])): ?> value="<?php echo e($banner['link']); ?>" <?php else: ?> value="<?php echo e(old('$banner_link')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="alt">Banner Alternative Text</label>
                                        <input type="text" class="form-control" placeholder="Enter banner alt text" name="alt" id="banneralt" <?php if(!empty($banner['alt'])): ?> value="<?php echo e($banner['alt']); ?>" <?php else: ?> value="<?php echo e(old('$alt')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <input type="submit" class="btn btn-primary btn-sm">
                        </div>
                    </div>
                    <!-- /.card -->
                </form>
                <!-- /.Add banner form -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\eCommerce\resources\views/admin/addEditBanners.blade.php ENDPATH**/ ?>