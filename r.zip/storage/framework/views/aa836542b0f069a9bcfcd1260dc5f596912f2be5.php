<?php 
    use App\Banner;
    $banners = Banner::getBanners();
    $bannerCount = count($banners);
?>

<?php if(isset($page_name) && $page_name == 'index'): ?>
<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item <?php if($key == 0): ?> active <?php endif; ?>">
				<div class="container">
					<a <?php if(!empty($banner['link'])): ?> href="<?php echo e(url($banner['link'])); ?>" <?php else: ?> href="javascript:void(0)" <?php endif; ?>><img style="width:100%" src="<?php echo e(asset('images/bannerImages/'.$banner['image'])); ?>" alt="<?php echo e($banner['alt']); ?>" title="<?php echo e($banner['title']); ?>"/></a>
					<div class="carousel-caption">
					</div>
				</div>
			</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
        <?php if($bannerCount > 1): ?>
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
        <?php endif; ?>
	</div>
</div>
<?php endif; ?>
<?php /**PATH D:\Projects\eCommerce\resources\views/front/banners/homePageBanner.blade.php ENDPATH**/ ?>