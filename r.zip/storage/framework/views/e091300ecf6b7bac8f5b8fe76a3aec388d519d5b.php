

<?php $__env->startSection('content'); ?>
<div class="span9">
    <ul class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
        <li class="active"><?php echo $categoryDetails['breadcrumbs']?></li>
    </ul>
    <h3> <?php echo e($categoryDetails['categoryDetails']['category_name']); ?> <small class="pull-right"> <?php echo e(count($categoryProducts)); ?> products are available </small></h3>
    <hr class="soft"/>
    <p>
        <?php echo e($categoryDetails['categoryDetails']['description']); ?>

    </p>
    <hr class="soft"/> 
    <input type="hidden" id="url" value="<?php echo e($url); ?>"/>
    <form class="form-horizontal span6" name="sortProducts" id="sortProducts">
        <div class="control-group">
            <label class="control-label alignL">Sort By</label>
            <select name="sort" id="sort">
                <option value="">Select</option>
                <option value="latest_products" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'latest_products'): ?> selected class="sortSelected" <?php endif; ?>>Latest Products</option>
                <option value="price_lowset" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_lowset'): ?> selected class="sortSelected" <?php endif; ?>>Lowest price first</option>
                <option value="price_highest" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_highest'): ?> selected class="sortSelected" <?php endif; ?>>Highest price first</option>
                <option value="products_a_z" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'products_a_z'): ?> selected class="sortSelected" <?php endif; ?>>Product name A - Z</option>
                <option value="products_z_a" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'products_z_a'): ?> selected class="sortSelected" <?php endif; ?>>Product name Z - A</option>
            </select>
        </div>
    </form>
    
    <!-- <div id="myTab" class="pull-right">
        <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="icon-list"></i></span></a>
        <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="icon-th-large"></i></span></a>
    </div> -->
    <br class="clr"/>
    <div class="tab-content" id="filter_products">
        <!-- products list view -->
        <!-- <div class="tab-pane" id="listView">
            <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="span2">
                        <?php $productImagePath = 'images/productImages/small/'.$product['product_image'] ?>
                        <?php if(!empty($product['product_image']) && file_exists($productImagePath)): ?>
                            <img class="listingPageListViewImage" src="<?php echo e(asset($productImagePath)); ?>" alt="">
                        <?php else: ?>
                            <img class="listingPageListViewImage" src="<?php echo e(asset('images/productImages/small/smallDummyImg.png')); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="span4">
                        <h3><?php echo e($product['product_name']); ?></h3>
                        <hr class="soft"/>
                        <h5>Brand: <?php echo e($product['brand']['name']); ?></h5>
                        <p><?php echo e($product['product_description']); ?></p>
                        <a class="btn btn-small pull-right" href="product_details.html">View Details</a>
                        <br class="clr"/>
                    </div>
                    <div class="span3 alignR">
                        <form class="form-horizontal qtyFrm">
                            <h3>Tk.<?php echo e($product['product_price']); ?></h3>
                            <label class="checkbox">
                                <input type="checkbox">  Adds product to compare
                            </label><br/>
                            
                            <a href="product_details.html" class="btn btn-large btn-primary"> Add to <i class=" icon-shopping-cart"></i></a>
                            <a href="product_details.html" class="btn btn-large"><i class="icon-zoom-in"></i></a>
                            
                        </form>
                    </div>
                </div>
                <hr class="soft"/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> -->

        <!-- products block view -->
        <?php echo $__env->make('front.products.ajaxProductView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <a href="compare.html" class="btn btn-large pull-right">Compare Product</a>
    <div class="pagination">
        <?php if(isset($_GET['sort']) && !empty($_GET['sort'])): ?>
            <?php echo e($categoryProducts->appends(['sort' => $_GET['sort']])->links()); ?>

        <?php else: ?>
            <?php echo e($categoryProducts->links()); ?>

        <?php endif; ?>
    </div>
    <br class="clr"/>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\eCommerce\resources\views/front/products/listing.blade.php ENDPATH**/ ?>