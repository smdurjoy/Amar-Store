<?php 
use App\Section;
$sections = Section::section();
?>

<div id="sidebar" class="span3">
    <div class="well well-small"><a id="myCart" href="product_summary.html"><img src="<?php echo e(asset('images/frontImages/ico-cart.png')); ?>" alt="cart">3 Items in your cart</a></div>
    <ul id="sideManu" class="nav nav-tabs nav-stacked">
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($section['categories']) > 0): ?>
            <li class="subMenu"><a><?php echo e($section['name']); ?></a>
            <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><a href="<?php echo e(url($category['url'])); ?>"><i class="icon-chevron-right"></i><strong><?php echo e($category['category_name']); ?></strong></a></li>
                    <?php $__currentLoopData = $category['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url($subCategories['url'])); ?>"><i class="icon-chevron-right"></i><?php echo e($subCategories['category_name']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <br/>
    <div class="thumbnail">
        <img src="<?php echo e(asset('images/frontImages/payment_methods.png')); ?>" title="Payment Methods" alt="Payments Methods">
        <div class="caption">
            <h5>Payment Methods</h5>
        </div>
    </div>
</div>
<?php /**PATH E:\Projects\eCommerce\resources\views/layouts/front/sidebar.blade.php ENDPATH**/ ?>