

<?php $__env->startSection('content'); ?>
<div class="span9">
    <div class="well well-small">
        <h4>Featured Products <small class="pull-right"><?php echo e($featuredItemsCount); ?> featured products</small></h4>
        <div class="row-fluid">
            <div id="featured" <?php if($featuredItemsCount > 4): ?> class="carousel slide" <?php endif; ?>>
                <div class="carousel-inner">
                    <?php $__currentLoopData = $featuredItemsChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $featuredItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item <?php if($key == 1): ?> active <?php endif; ?>">
                            <ul class="thumbnails">
                                <?php $__currentLoopData = $featuredItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="span3">
                                    <div class="thumbnail">
                                        <i class="tag"></i>
                                        <a href="product_details.html">
                                            <?php $productImagePath = 'images/productImages/small/'.$item['product_image'] ?>
                                            <?php if(!empty($item['product_image']) && file_exists($productImagePath)): ?>
                                                <img src="<?php echo e(asset($productImagePath)); ?>" alt="">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/productImages/small/smallDummyImg.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </a>
                                        <div class="caption">
                                            <h5><?php echo e($item['product_name']); ?></h5>
                                            <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">Tk.<?php echo e($item['product_price']); ?></span></h4>
                                        </div>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if($featuredItemsCount > 4): ?> 
                    <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
                    <a class="right carousel-control" href="#featured" data-slide="next">›</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <h4>Latest Products </h4>
    <ul class="thumbnails">
    <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <li class="span3">
            <div class="thumbnail">
                <a  href="product_details.html">
                    <?php $productImagePath = 'images/productImages/small/'.$latestProduct['product_image'] ?>
                    <?php if(!empty($latestProduct['product_image']) && file_exists($productImagePath)): ?>
                        <img class="featuredProductImage" src="<?php echo e(asset('images/productImages/small/'.$latestProduct['product_image'])); ?>" alt="">
                    <?php else: ?>
                        <img class="featuredProductImage" src="<?php echo e(asset('images/productImages/small/smallDummyImg.png')); ?>" alt="">
                    <?php endif; ?>
                </a>
                <div class="caption">
                    <h5><?php echo e($latestProduct['product_name']); ?></h5> 
                    <p><?php echo e($latestProduct['product_code']); ?></p>
                    <h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">Tk.<?php echo e($latestProduct['product_price']); ?></a></h4>
                </div>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\eCommerce\resources\views/front/index.blade.php ENDPATH**/ ?>