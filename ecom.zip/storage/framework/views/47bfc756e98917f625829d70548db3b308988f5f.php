<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Catalogues</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active"><a href="<?php echo e(url('admin/add-edit-product')); ?>">Add Products</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(Session::has('successMessage')): ?>
                    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                        <?php echo e(Session::get('successMessage')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

            <!-- Add Product form -->
                <form method="post" <?php if(empty($productData['id'])): ?> action="<?php echo e(url('admin/add-edit-product')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-product/'.$productData['id'])); ?>" <?php endif; ?> id="addProductForm" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title"> <?php echo e($title); ?> </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Category</label>
                                        <select name="category_id" class="form-control select2" style="width: 100%;" id="categoryId">
                                            <option selected="selected">Select</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <optgroup label="<?php echo e($section['name']); ?>"></optgroup>
                                                <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category['id']); ?>" <?php if(!empty(@old('category_id')) && $category['id'] == @old('category_id')): ?> selected <?php elseif(!empty($productData['category_id']) && $productData['category_id'] == $category['id']): ?> selected <?php endif; ?>>&nbsp;&nbsp;--&nbsp;
                                                        <?php echo e($category['category_name']); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $category['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($subcategory['id']); ?>" <?php if(!empty(@old('category_id')) && $subcategory['id'] == @old('category_id')): ?> selected <?php elseif(!empty($productData['category_id']) && $productData['category_id'] == $subcategory['id']): ?> selected <?php endif; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--&nbsp;
                                                            <?php echo e($subcategory['category_name']); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="product_name">Product Name</label>
                                        <input type="text" class="form-control" name="product_name" id="productName" placeholder="Enter Product Name" <?php if(!empty($productData['product_name'])): ?> value="<?php echo e($productData['product_name']); ?>" <?php else: ?> value="<?php echo e(old('$product_name')); ?>" <?php endif; ?>>
                                    </div>
                                    <div class="form-group">
                                        <label for="product_color">Product Color</label>
                                        <input type="text" class="form-control" placeholder="Enter Product Color" name="product_color" id="productColor" <?php if(!empty($productData['product_color'])): ?> value="<?php echo e($productData['product_color']); ?>" <?php else: ?> value="<?php echo e(old('product_color')); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <!-- /.col -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Brand</label>
                                        <select name="brand_id" class="form-control select2" style="width: 100%;" id="brand_id">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand['id']); ?>" <?php if(!empty($productData['brand_id']) && $productData['brand_id'] == $brand['id']): ?> selected <?php endif; ?>><?php echo e($brand['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="product_code">Product Code</label>
                                        <input type="text" class="form-control" name="product_code" id="productCode" placeholder="Enter Product Code" <?php if(!empty($productData['product_code'])): ?> value="<?php echo e($productData['product_code']); ?>" <?php else: ?> value="<?php echo e(old('$product_code')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                    <div class="form-group">
                                        <label for="product_image">Product Image</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="product_image" name="product_image">
                                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                            </div>
                                        </div>
                                        <div>Recommended size Width: 1040px, Height:1200px</div>
                                    </div>
                                    <div>
                                        <?php if(!empty($productData['product_image'])): ?>
                                            <img src="<?php echo e(asset('images/productImages/small/'.$productData['product_image'])); ?>" alt="image!" style="margin-top: 5px; height: 80px; width: 80px; margin-bottom: 5px">&nbsp; <a class="btn btn-danger deleteBtn confirmDelete" href="javascript:void(0)" record="product-image" recordId="<?php echo e($productData['id']); ?>" title="Delete Image"><i class="fas fa-trash"></i></a>
                                        <?php endif; ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->

                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="product_weight">Product Weight</label>
                                        <input type="text" class="form-control" placeholder="Enter Product Weight" name="product_weight" id="productWeight" <?php if(!empty($productData['product_weight'])): ?> value="<?php echo e($productData['product_weight']); ?>" <?php else: ?> value="<?php echo e(old('product_weight')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="product_price">Product Price</label>
                                        <input type="text" class="form-control" placeholder="Enter Product Price" name="product_price" id="productPrice" <?php if(!empty($productData['product_price'])): ?> value="<?php echo e($productData['product_price']); ?>" <?php else: ?> value="<?php echo e(old('product_price')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="product_discount">Product Discount (%)</label>
                                        <input type="text" class="form-control" placeholder="Enter Product Discount" name="product_discount" id="productDiscount" <?php if(!empty($productData['product_discount'])): ?> value="<?php echo e($productData['product_discount']); ?>" <?php else: ?> value="<?php echo e(old('product_discount')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="product_video">Product Video</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="product_video" name="product_video">
                                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if(!empty($productData['product_video'])): ?>
                                        <a href="<?php echo e(url('videos/productVideos/'.$productData['product_video'])); ?>" download>Download Video</a>
                                        ||
                                        <a class="btn btn-danger deleteBtn confirmDelete" href="javascript:void(0)" record="product-video" recordId="<?php echo e($productData['id']); ?>" title="Delete Video"><i class="fas fa-trash"></i></a>
                                    <?php endif; ?>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="wash_care">Wash Care</label>
                                        <textarea class="form-control" rows="3" placeholder="Enter Wash Care ..." name="wash_care" id="wash_care"><?php if(!empty($productData['wash_care'])): ?> <?php echo e($productData['wash_care']); ?> <?php else: ?> <?php echo e(old('wash_care')); ?> <?php endif; ?></textarea>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="product_description">Product Description</label>
                                        <textarea class="form-control" rows="3" placeholder="Enter Product Description ..." name="product_description" id="productDes"><?php if(!empty($productData['product_description'])): ?> <?php echo e($productData['product_description']); ?> <?php else: ?> <?php echo e(old('product_description')); ?> <?php endif; ?></textarea>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="meta_description">Meta Description</label>
                                        <textarea class="form-control" rows="3" placeholder="Enter Meta Description ..." name="meta_description" id="metaDes"><?php if(!empty($productData['meta_description'])): ?> <?php echo e($productData['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>Select Fabric</label>
                                        <select name="fabric" class="form-control select2" style="width: 100%;" id="category_id">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $fabricArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fabric['filter_value']); ?>" <?php if(!empty($productData['fabric']) && $productData['fabric'] == $fabric['filter_value']): ?> selected <?php endif; ?>><?php echo e($fabric['filter_value']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>Select Sleeve</label>
                                        <select name="sleeve" class="form-control select2" style="width: 100%;" id="sleeve">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $sleeveArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sleeve['filter_value']); ?>" <?php if(!empty($productData['sleeve']) && $productData['sleeve'] == $sleeve['filter_value']): ?> selected <?php endif; ?>><?php echo e($sleeve['filter_value']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>Select Pattern</label>
                                        <select name="pattern" class="form-control select2" style="width: 100%;" id="pattern">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $patternArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pattern['filter_value']); ?>" <?php if(!empty($productData['pattern']) && $productData['pattern'] == $pattern['filter_value']): ?> selected <?php endif; ?>><?php echo e($pattern['filter_value']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>Select Fit</label>
                                        <select name="fit" class="form-control select2" style="width: 100%;" id="fit">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $fitArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fit['filter_value']); ?>" <?php if(!empty($productData['fit']) && $productData['fit'] == $fit['filter_value']): ?> selected <?php endif; ?>><?php echo e($fit['filter_value']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label>Select Occasion</label>
                                        <select name="occasion" class="form-control select2" style="width: 100%;" id="occasion">
                                            <option value="" selected>Select</option>
                                            <?php $__currentLoopData = $occasionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($occasion['filter_value']); ?>" <?php if(!empty($productData['occasion']) && $productData['occasion'] == $occasion['filter_value']): ?> selected <?php endif; ?>><?php echo e($occasion['filter_value']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="meta_title">Meta Title</label>
                                        <input type="text" class="form-control" placeholder="Enter Meta Title" name="meta_title" id="metaTitle" <?php if(!empty($productData['meta_title'])): ?> value="<?php echo e($productData['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="meta_keywords">Meta Keyword</label>
                                        <input type="text" class="form-control" placeholder="Enter Meta Keyword" name="meta_keywords" id="productUrl" <?php if(!empty($productData['meta_keywords'])): ?> value="<?php echo e($productData['meta_keywords']); ?>" <?php else: ?> value="<?php echo e(old('meta_keywords')); ?>" <?php endif; ?>>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="featured">Featured Item</label>
                                <input type="checkbox" id="is_featured" name="is_featured" value="Yes" <?php if(!empty($productData['is_featured']) && $productData['is_featured'] == "Yes"): ?> checked <?php endif; ?>>
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <input type="submit" class="btn btn-primary btn-sm">
                            <a href="<?php echo e(url('admin/products')); ?>" class="btn btn-dark btn-sm">Go back</a>
                        </div>
                    </div>
                    <!-- /.card -->
                </form>
                <!-- /.Add product form -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\eCommerce\resources\views/admin/addEditProduct.blade.php ENDPATH**/ ?>