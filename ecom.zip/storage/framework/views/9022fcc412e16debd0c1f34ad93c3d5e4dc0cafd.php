<?php $__env->startSection('content'); ?>
<div class="span9">
    <ul class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
        <li class="active"><?php echo $categoryDetails['breadcrumbs']?></li>
    </ul>
    <h3> <?php echo e($categoryDetails['categoryDetails']['category_name']); ?> <small class="pull-right"> <?php echo e(count($categoryProducts)); ?> products are available </small></h3>
    <hr class="soft"/>
    <p>
        <?php echo e($categoryDetails['categoryDetails']['description']); ?>

    </p>
    <hr class="soft"/>
    <input type="hidden" id="url" value="<?php echo e($url); ?>"/>
    <form class="form-horizontal span6" name="sortProducts" id="sortProducts">
        <div class="control-group">
            <label class="control-label alignL">Sort By</label>
            <select name="sort" id="sort">
                <option value="">Select</option>
                <option value="latest_products" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'latest_products'): ?> selected class="sortSelected" <?php endif; ?>>Latest Products</option>
                <option value="price_lowset" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_lowset'): ?> selected class="sortSelected" <?php endif; ?>>Lowest price first</option>
                <option value="price_highest" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_highest'): ?> selected class="sortSelected" <?php endif; ?>>Highest price first</option>
                <option value="products_a_z" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'products_a_z'): ?> selected class="sortSelected" <?php endif; ?>>Product name A - Z</option>
                <option value="products_z_a" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'products_z_a'): ?> selected class="sortSelected" <?php endif; ?>>Product name Z - A</option>
            </select>
        </div>
    </form>

    <br class="clr"/>
    <div class="tab-content" id="filter_products">
        <?php echo $__env->make('front.products.ajaxProductView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <a href="compare.html" class="btn btn-large pull-right">Compare Product</a>
    <div class="pagination">
        <?php if(isset($_GET['sort']) && !empty($_GET['sort'])): ?>
            <?php echo e($categoryProducts->appends(['sort' => $_GET['sort']])->links()); ?>

        <?php else: ?>
            <?php echo e($categoryProducts->links()); ?>

        <?php endif; ?>
    </div>
    <br class="clr"/>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/durjoy/Projects/eCommerce/resources/views/front/products/listing.blade.php ENDPATH**/ ?>