<?php
use App\Section;
use App\Cart;
use Illuminate\Support\Facades\Auth;

$sections = Section::section();

if(Auth::check()) {
    $countCarts = Cart::where('user_id', Auth::user()->id)->count();
} else {
    $countCarts = Cart::where('session_id', \Illuminate\Support\Facades\Session::get('session_id'))->count();
}
?>

<div id="sidebar" class="span3">
    <div class="well well-small"><a id="myCart" href="<?php echo e(url('cart')); ?>"><img src="<?php echo e(asset('images/frontImages/ico-cart.png')); ?>" alt="cart"><?php echo e($countCarts); ?> Items in your cart</a></div>
    <ul id="sideManu" class="nav nav-tabs nav-stacked">
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($section['categories']) > 0): ?>
            <li class="subMenu"><a><?php echo e($section['name']); ?></a>
            <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><a href="<?php echo e(url($category['url'])); ?>"><i class="icon-chevron-right"></i><strong><?php echo e($category['category_name']); ?></strong></a></li>
                    <?php $__currentLoopData = $category['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url($subCategories['url'])); ?>"><i class="icon-chevron-right"></i><?php echo e($subCategories['category_name']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul> <br>
    <?php if(isset($pageName) && $pageName = 'listing'): ?>
        <div class="well well-small">
            <h5>Fabric</h5>
            <?php $__currentLoopData = $fabricArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input class="fabric" type="checkbox" style="margin-top: -3px" name="fabric[]" id="<?php echo e($fabric['filter_value']); ?>" value="<?php echo e($fabric['filter_value']); ?>">
                <?php echo e($fabric['filter_value']); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="well well-small">
            <h5>Sleeve</h5>
            <?php $__currentLoopData = $sleeveArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input class="sleeve" type="checkbox" style="margin-top: -3px" name="sleeve[]" id="<?php echo e($sleeve['filter_value']); ?>" value="<?php echo e($sleeve['filter_value']); ?>">
                <?php echo e($sleeve['filter_value']); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="well well-small">
            <h5>Pattern</h5>
            <?php $__currentLoopData = $patternArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input class="pattern" type="checkbox" style="margin-top: -3px" name="pattern[]" id="<?php echo e($pattern['filter_value']); ?>" value="<?php echo e($pattern['filter_value']); ?>">
                <?php echo e($pattern['filter_value']); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="well well-small">
            <h5>Fit</h5>
            <?php $__currentLoopData = $fitArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input class="fit" type="checkbox" style="margin-top: -3px" name="fit[]" id="<?php echo e($fit['filter_value']); ?>" value="<?php echo e($fit['filter_value']); ?>">
                <?php echo e($fit['filter_value']); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="well well-small">
            <h5>Occasion</h5>
            <?php $__currentLoopData = $occasionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input class="occasion" type="checkbox" style="margin-top: -3px" name="occasion[]" id="<?php echo e($occasion['filter_value']); ?>" value="<?php echo e($occasion['filter_value']); ?>">
                <?php echo e($occasion['filter_value']); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <br/>
    <div class="thumbnail">
        <img src="<?php echo e(asset('images/frontImages/payment_methods.png')); ?>" title="Payment Methods" alt="Payments Methods">
        <div class="caption">
            <h5>Payment Methods</h5>
        </div>
    </div>
</div>
<?php /**PATH /home/durjoy/Projects/eCommerce/resources/views/layouts/front/sidebar.blade.php ENDPATH**/ ?>