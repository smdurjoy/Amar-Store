<?php
use App\Section;
use App\Cart;
use Illuminate\Support\Facades\Auth;

$sections = Section::section();
if(Auth::check()) {
    $countCarts = Cart::where('user_id', Auth::user()->id)->count();
} else {
    $countCarts = Cart::where('session_id', \Illuminate\Support\Facades\Session::get('session_id'))->count();
}

?>

<div id="header">
	<div class="container">
		<div id="welcomeLine" class="row">
			<div class="span6">Welcome!<strong> User</strong></div>
			<div class="span6">
				<div class="pull-right">
					<a href="<?php echo e(url('cart')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [ <?php echo e($countCarts); ?> ] Items in your cart </span> </a>
				</div>
			</div>
		</div>
		<!-- Navbar ================================================== -->
		<section id="navbar">
		  <div class="navbar">
		    <div class="navbar-inner">
		      <div class="container">
		        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		        </a>
		        <a class="brand" href="<?php echo e(url('/')); ?>">Amar Store</a>
		        <div class="nav-collapse">
		          <ul class="nav">
                    <li class="<?php if(Request::is('/')): ?> active <?php endif; ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>

                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($section['categories']) > 0): ?>
                            <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($section['name']); ?> <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="divider"></li>
                                    <li class="nav-header"><a href="<?php echo e(url($category['url'])); ?>"><?php echo e($category['category_name']); ?></a></li>
                                    <?php $__currentLoopData = $category['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url($subCategories['url'])); ?>"><?php echo e($subCategories['category_name']); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		            <li><a href="#">About</a></li>
		          </ul>
		          <form class="navbar-search pull-left" action="#">
		            <input type="text" class="search-query span2" placeholder="Search"/>
		          </form>
		          <ul class="nav pull-right">
		            <li><a href="#">Contact</a></li>
		            <li class="divider-vertical"></li>
		            <li><a href="#">Login</a></li>
		          </ul>
		        </div><!-- /.nav-collapse -->
		      </div>
		    </div><!-- /navbar-inner -->
		  </div><!-- /navbar -->
		</section>
	</div>
</div>
<?php /**PATH D:\Projects\eCommerce\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>