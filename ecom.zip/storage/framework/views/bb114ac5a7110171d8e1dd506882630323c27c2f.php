<div class="tab-pane  active" id="blockView">
    <ul class="thumbnails">
    <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="span3">
            <div class="thumbnail">
                <a href="product_details.html">
                    <?php $productImagePath = 'images/productImages/small/'.$product['product_image'] ?>
                    <?php if(!empty($product['product_image']) && file_exists($productImagePath)): ?>
                        <img class="listingPageProductImage" src="<?php echo e(asset($productImagePath)); ?>" alt="">
                    <?php else: ?>
                        <img class="listingPageProductImage" src="<?php echo e(asset('images/productImages/small/smallDummyImg.png')); ?>" alt="">
                    <?php endif; ?>
                </a> 
                <div class="caption">
                    <h5><?php echo e($product['product_name']); ?></h5>
                    <p><?php echo e($product['brand']['name']); ?></p>
                    <h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">Tk.<?php echo e($product['product_price']); ?></a></h4>
                </div>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <hr class="soft"/>
</div><?php /**PATH E:\Projects\eCommerce\resources\views/front/products/ajaxProductView.blade.php ENDPATH**/ ?>