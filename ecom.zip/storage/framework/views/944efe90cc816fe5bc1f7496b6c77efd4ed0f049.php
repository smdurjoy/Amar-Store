<?php use App\Product; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Product</th>
            <th>Description</th>
            <th>Size/Code</th>
            <th>Quantity/Update</th>
            <th>Unit Price</th>
            <th>Discount</th>
            <th>Sub Total</th>
        </tr>
    </thead>

    <tbody>
        <?php $totalPrice = 0;?>
        <?php $__currentLoopData = $userCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $attrPrice = Product::getDiscountedAttrPrice($item['product_id'], $item['size']);?>
            <tr>
                <td> <img width="60" src="<?php echo e(asset('images/productImages/small/'.$item['product']['product_image'])); ?>" alt=""/></td>
                <td><?php echo e($item['product']['product_name']); ?><br/>Color : <?php echo e($item['product']['product_color']); ?></td>
                <td><?php echo e($item['size']); ?><br/>Code : <?php echo e($item['product']['product_code']); ?></td>
                <td>
                    <div class="input-append"><input class="span1" style="max-width:34px" value="<?php echo e($item['quantity']); ?>" id="appendedInputButtons" size="16" type="text"><button class="btn cartItemUpdate qtyMinus" type="button" data-id="<?php echo e($item['id']); ?>"><i class="icon-minus"></i></button><button class="btn cartItemUpdate qtyPlus" type="button" data-id="<?php echo e($item['id']); ?>"><i class="icon-plus"></i></button><button class="btn btn-danger cartItemDelete" data-id="<?php echo e($item['id']); ?>" type="button"><i class="icon-remove icon-white"></i></button>	</div>
                </td>
                <td>Tk.<?php echo e($attrPrice['product_price']); ?></td> 
                <td>Tk.<?php echo e($attrPrice['discount']); ?></td>
                <td>Tk.<?php echo e($attrPrice['final_price'] * $item['quantity']); ?></td>
            </tr>
            <?php $totalPrice += ($attrPrice['final_price'] * $item['quantity'])?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td colspan="6" style="text-align:right">Total Price: </td>
            <td> Tk.<?php echo e($totalPrice); ?></td>
        </tr>
        <tr>
            <td colspan="6" style="text-align:right">Voucher Discount: </td>
            <td> Tk.0.00</td>
        </tr>
        <tr>
            <td colspan="6" style="text-align:right"><strong>GRAND TOTAL</strong></td>
            <td class="label label-important" style="display:block"> <strong> Tk.<?php echo e($totalPrice); ?> </strong></td>
        </tr>
    </tbody>
</table><?php /**PATH /home/durjoy/Projects/eCommerce/resources/views/front/products/cartItems.blade.php ENDPATH**/ ?>