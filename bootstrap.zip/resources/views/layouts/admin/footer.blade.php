<footer class="main-footer">
    <strong>&copy; <a href="https://smdurjoy.com" target="_blank">smdurjoy</a></strong>
    all rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        Developed by <a href="https://smdurjoy.com" target="_blank">smdurjoy</a>
    </div>
</footer>
